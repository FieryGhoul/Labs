from django import forms

GROCERY_CHOICES = (
    ('Wheat', 'Wheat'),
    ('Jaggery', 'Jaggery'),
    ('Dal', 'Dal'),
)

class GroceryForm(forms.Form):

    items = forms.MultipleChoiceField(
        choices=GROCERY_CHOICES,
        widget=forms.CheckboxSelectMultiple,
        label="Select Item",
        error_messages={
            'required': 'Please select at least one item.'
        }
    )