from django.urls import path
from . import views

urlpatterns = [
    path('grocery/', views.grocery_view, name='grocery'),
]