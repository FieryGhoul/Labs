from django.shortcuts import render
from .forms import GroceryForm

# Price Dictionary
PRICE_LIST = {
    'Wheat': 40,
    'Jaggery': 60,
    'Dal': 80,
}

def grocery_view(request):
    form = GroceryForm(request.POST or None)
    selected_data = []

    if request.method == "POST":
        if form.is_valid():
            selected_items = form.cleaned_data['items']

            for item in selected_items:
                selected_data.append({
                    'name': item,
                    'price': PRICE_LIST.get(item)
                })

    return render(request, "grocery.html", {
        'form': form,
        'selected_data': selected_data
    })