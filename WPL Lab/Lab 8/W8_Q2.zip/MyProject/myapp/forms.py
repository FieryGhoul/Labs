from django import forms

SUBJECT_CHOICES = (
    ('Math', 'Math'),
    ('Science', 'Science'),
    ('History', 'History'),
    ('Computer', 'Computer'),
)

class StudentForm(forms.Form):

    name = forms.CharField(
        max_length=50,
        label="Student Name",
        error_messages={'required': 'Name is required'}
    )

    roll = forms.IntegerField(
        min_value=1,
        label="Roll Number",
        error_messages={'required': 'Roll number is required'}
    )

    subject = forms.ChoiceField(
        choices=SUBJECT_CHOICES,
        widget=forms.Select,
        label="Subject"
    )