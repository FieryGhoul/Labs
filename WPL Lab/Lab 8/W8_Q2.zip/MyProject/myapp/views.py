from django.shortcuts import render, redirect
from .forms import StudentForm

def first_page(request):
    form = StudentForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():

            request.session['name'] = form.cleaned_data['name']
            request.session['roll'] = form.cleaned_data['roll']
            request.session['subject'] = form.cleaned_data['subject']

            return redirect('second_page')

    return render(request, "firstPage.html", {'form': form})


def second_page(request):

    name = request.session.get('name')
    roll = request.session.get('roll')
    subject = request.session.get('subject')

    return render(request, "secondPage.html", {
        'name': name,
        'roll': roll,
        'subject': subject
    })