from django import forms

CAR_CHOICES = (
    ('Toyota', 'Toyota'),
    ('BMW', 'BMW'),
    ('Audi', 'Audi'),
    ('Tesla', 'Tesla'),
)

class CarForm(forms.Form):
    manufacturer = forms.ChoiceField(
        choices=CAR_CHOICES,
        widget=forms.Select,
        label="Car Manufacturer"
    )

    model = forms.CharField(
        max_length=50,
        min_length=2,
        label="Model Name",
        error_messages={
            'required': 'Model name cannot be empty!',
            'min_length': 'Model must contain at least 2 characters.'
        }
    )