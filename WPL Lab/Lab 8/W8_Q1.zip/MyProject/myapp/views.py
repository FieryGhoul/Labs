from django.shortcuts import render
from .forms import CarForm

def car_page(request):
    form = CarForm(request.POST or None)

    if request.method == "POST":
        if form.is_valid():
            manufacturer = form.cleaned_data['manufacturer']
            model = form.cleaned_data['model']

            return render(request, "car_result.html", {
                'manufacturer': manufacturer,
                'model': model
            })

    return render(request, "car_form.html", {'form': form})