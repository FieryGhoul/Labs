from django.shortcuts import render

def magazine(request):
    data = {}

    if request.method == "POST":
        data['title'] = request.POST.get('title')
        data['bgcolor'] = request.POST.get('bgcolor')
        data['fontcolor'] = request.POST.get('fontcolor')
        data['fontsize'] = request.POST.get('fontsize')

    return render(request, 'base.html', data)
