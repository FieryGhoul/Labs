from django.urls import path
from . import views

urlpatterns = [
    path('', views.format_text, name='format_text'),
]
