from django.shortcuts import render

def format_text(request):
    context = {}

    if request.method == "POST":
        name = request.POST.get("name")
        message = request.POST.get("message")

        styles = []
        if request.POST.get("bold"):
            styles.append("font-weight:bold")
        if request.POST.get("italic"):
            styles.append("font-style:italic")
        if request.POST.get("underline"):
            styles.append("text-decoration:underline")

        color = request.POST.get("color", "black")

        context["output"] = f"Name: {name} | Message: {message}"
        context["style"] = ";".join(styles)
        context["color"] = color

    return render(request, "format.html", context)
