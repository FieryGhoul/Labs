from django.shortcuts import render

def calculator(request):
    result = None

    if request.method == "POST":
        num1 = int(request.POST.get("num1"))
        num2 = int(request.POST.get("num2"))
        operation = request.POST.get("operation")

        if operation == "add":
            result = num1 + num2
        elif operation == "sub":
            result = num1 - num2
        elif operation == "mul":
            result = num1 * num2
        elif operation == "div":
            if num2 != 0:
                result = num1 / num2
            else:
                result = "Division by zero not allowed"

    return render(request, "base.html", {"result": result})
