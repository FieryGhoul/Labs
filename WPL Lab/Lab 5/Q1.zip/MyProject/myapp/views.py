from django.shortcuts import render

def student_form(request):
    details = ""
    percentage = None

    if request.method == "POST":
        name = request.POST.get("name")
        dob = request.POST.get("dob")
        address = request.POST.get("address")
        contact = request.POST.get("contact")
        email = request.POST.get("email")

        eng = int(request.POST.get("english"))
        phy = int(request.POST.get("physics"))
        chem = int(request.POST.get("chemistry"))

        total = eng + phy + chem
        percentage = total / 3

        details = (
            f"Name: {name}\n"
            f"Date of Birth: {dob}\n"
            f"Address: {address}\n"
            f"Contact Number: {contact}\n"
            f"Email ID: {email}\n"
            f"English Marks: {eng}\n"
            f"Physics Marks: {phy}\n"
            f"Chemistry Marks: {chem}"
        )

    return render(request, "base.html", {
        "details": details,
        "percentage": percentage
    })
