from django.shortcuts import render
from datetime import date

def promotion_check(request):
    result = None
    emp_ids = ['EMP101', 'EMP102', 'EMP103', 'EMP104']

    if request.method == "POST":
        doj_str = request.POST.get("doj")

        if doj_str:
            doj = date.fromisoformat(doj_str)
            today = date.today()

            experience_years = (today - doj).days / 365

            if experience_years > 5:
                result = "YES"
            else:
                result = "NO"

    return render(request, "base.html", {
        "emp_ids": emp_ids,
        "result": result
    })
