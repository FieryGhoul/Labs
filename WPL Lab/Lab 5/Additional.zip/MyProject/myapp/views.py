from django.shortcuts import render

# Hardcoded captcha
CAPTCHA_TEXT = "A9B7C"

# Global attempt counter
attempts = 0

def captcha_view(request):
    global attempts
    message = ""
    disable = False

    if request.method == "POST":
        user_input = request.POST.get("captcha_input")

        if user_input == CAPTCHA_TEXT:
            message = " Captcha Matched Successfully"
            attempts = 0
        else:
            attempts += 1
            message = " Captcha Mismatch"

            if attempts >= 3:
                disable = True
                message = " More than 3 wrong attempts. Textbox disabled."

    context = {
        "captcha": CAPTCHA_TEXT,
        "message": message,
        "disable": disable,
        "attempts": attempts
    }

    return render(request, "base.html", context)
