from django.shortcuts import render, redirect
from .models import Category, Page
from .forms import CategoryForm, PageForm

# Add Category
def add_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_category')
    else:
        form = CategoryForm()
    return render(request, 'add_category.html', {'form': form})

# Add Page
def add_page(request):
    if request.method == 'POST':
        form = PageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_page')
    else:
        form = PageForm()
    return render(request, 'add_page.html', {'form': form})

# Show all categories and pages
def show_data(request):
    categories = Category.objects.all()
    pages = Page.objects.all()
    return render(request, 'show_data.html', {'categories': categories, 'pages': pages})