from django.shortcuts import render, redirect
from .models import Works, Lives
from .forms import WorksForm, CompanySearchForm

def add_work(request):
    if request.method == 'POST':
        form = WorksForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_work')  # redirect to same page after insertion
    else:
        form = WorksForm()
    return render(request, 'add_work.html', {'form': form})

def search_company(request):
    results = []
    if request.method == 'POST':
        form = CompanySearchForm(request.POST)
        if form.is_valid():
            company_name = form.cleaned_data['company_name']
            # Get all people working in the company
            workers = Works.objects.filter(company_name=company_name)
            # Join manually with Lives table
            for w in workers:
                live = Lives.objects.filter(person_name=w.person_name).first()
                city = live.city if live else "Unknown"
                results.append({'name': w.person_name, 'city': city})
    else:
        form = CompanySearchForm()
    return render(request, 'search_company.html', {'form': form, 'results': results})