from django.urls import path
from . import views

urlpatterns = [
    path('humans/manage/', views.human_manage, name='human_manage'),
]