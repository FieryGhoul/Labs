from django.shortcuts import render, redirect, get_object_or_404
from .models import Human
from .forms import HumanForm

def human_manage(request):
    humans = Human.objects.all()
    selected_human = None

    # Check if a human is selected from dropdown
    human_id = request.GET.get('human_id')
    if human_id:
        selected_human = get_object_or_404(Human, id=human_id)
        form = HumanForm(instance=selected_human)
    else:
        form = HumanForm()

    # POST handling
    if request.method == "POST":
        action = request.POST.get('action')
        human_id = request.POST.get('human_id')
        if human_id:
            human = get_object_or_404(Human, id=human_id)
        else:
            human = None

        if action == "Update" and human:
            form = HumanForm(request.POST, instance=human)
            if form.is_valid():
                form.save()
                return redirect('human_manage')

        elif action == "Delete" and human:
            human.delete()
            return redirect('human_manage')

        elif action == "Add":
            form = HumanForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('human_manage')

    return render(request, 'myapp/human_manage.html', {
        'humans': humans,
        'form': form,
        'selected_human': selected_human
    })