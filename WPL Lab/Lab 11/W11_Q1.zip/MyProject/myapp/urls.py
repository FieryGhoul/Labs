from django.urls import path
from . import views

urlpatterns = [
    path('books/add/', views.book_create, name='book_create'),
    path('books/', views.book_list, name='book_list'),
]