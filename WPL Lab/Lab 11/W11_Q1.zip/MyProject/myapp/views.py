# views.py
from django.shortcuts import render, redirect
from .forms import AuthorForm, PublisherForm, BookForm
from .models import Author, Publisher, Book

def book_create(request):
    if request.method == "POST":
        book_form = BookForm(request.POST)
        if book_form.is_valid():
            book_form.save()
            return redirect('book_list')
    else:
        book_form = BookForm()
    return render(request, 'book_form.html', {'form': book_form})

def book_list(request):
    books = Book.objects.all()
    return render(request, 'book_list.html', {'books': books})