from django.shortcuts import render, redirect
from .forms import StudentForm
from .models import Student

def student_manage(request):
    # Handle form submission
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_manage')
    else:
        form = StudentForm()

    # Fetch all students to display
    students = Student.objects.all()
    
    return render(request, 'myapp/student_manage.html', {
        'form': form,
        'students': students
    })