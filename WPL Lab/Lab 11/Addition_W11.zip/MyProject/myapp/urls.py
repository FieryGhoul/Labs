from django.urls import path
from . import views

urlpatterns = [
    path('students/manage/', views.student_manage, name='student_manage'),
]