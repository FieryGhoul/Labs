from django.urls import path
from . import views

urlpatterns = [
    path('products/add/', views.product_create, name='product_create'),
    path('', views.index, name='index'),
]