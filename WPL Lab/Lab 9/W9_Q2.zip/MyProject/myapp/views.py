from django.shortcuts import render

votes = {
    "good": 0,
    "satisfactory": 0,
    "bad": 0
}

def vote(request):
    if request.method == "POST":
        choice = request.POST.get("rating")

        if choice in votes:
            votes[choice] += 1

    total = sum(votes.values())

    if total > 0:
        good_percent = votes["good"] * 100 / total
        sat_percent = votes["satisfactory"] * 100 / total
        bad_percent = votes["bad"] * 100 / total
    else:
        good_percent = sat_percent = bad_percent = 0

    context = {
        "good": good_percent,
        "sat": sat_percent,
        "bad": bad_percent
    }

    return render(request, "vote.html", context)