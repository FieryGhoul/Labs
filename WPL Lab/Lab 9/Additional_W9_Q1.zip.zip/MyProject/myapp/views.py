from django.shortcuts import render, redirect

prices = {
    "HP": 500,
    "Nokia": 300,
    "Samsung": 450,
    "Motorola": 350,
    "Apple": 900
}

def index(request):

    if request.method == "POST":
        brand = request.POST.get('brand')
        items = request.POST.getlist('items')
        qty = int(request.POST.get('qty'))

        total = prices[brand] * qty

        request.session['brand'] = brand
        request.session['items'] = items
        request.session['qty'] = qty
        request.session['total'] = total

        return redirect('bill')   # redirect to bill page

    return render(request, "index.html")


def bill(request):

    context = {
        "brand": request.session.get('brand'),
        "items": request.session.get('items'),
        "qty": request.session.get('qty'),
        "total": request.session.get('total')
    }

    return render(request, "bill.html", context)