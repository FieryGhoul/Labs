from django.contrib import admin
from django.urls import path
from myapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.feedback),   # home page
    path('feedback/', views.feedback, name='feedback'),
]