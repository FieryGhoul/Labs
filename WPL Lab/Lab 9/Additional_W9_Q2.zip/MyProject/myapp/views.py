from django.shortcuts import render

def feedback(request):

    message = ""

    if request.method == "POST":
        name = request.POST.get("name")
        message = "Thank you {} for your feedback".format(name)

    return render(request, "feedback.html", {"message": message})